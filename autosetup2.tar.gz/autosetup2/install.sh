#!/bin/bash

if [ "$EUID" -ne 0 ]; then
  echo "Please run as root"
  exit 1
fi

echo "AutoSetup Install"
cp -R * /usr/local/bin
cp autoSetup.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable autoSetup.service
echo "Install finished."
