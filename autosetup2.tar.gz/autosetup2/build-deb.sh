#!/bin/bash

VERSION=$1
ARCH="amd64"
RANDOMDIR=`echo $RANDOM | md5sum | head -c 20; echo;`
PARENTDIR="/tmp"
CURRENTPATH=`pwd`

if [ -z $VERSION ]; then
	echo "Syntax error. Mission Version."
	echo ""
	echo "Syntax: $0 <version>"
	echo ""
	exit 1
fi

git clone http://mka:ed306f558413c243ad3a3914e6e478fd74765b01@git.openlab.dk:/mka/autoSetup.git $PARENTDIR/$RANDOMDIR

mkdir -p $PARENTDIR/autosetup_$VERSION\_$ARCH/etc/systemd/system/
mkdir -p $PARENTDIR/autosetup_$VERSION\_$ARCH/opt/autosetup
mkdir -p $PARENTDIR/autosetup_$VERSION\_$ARCH/DEBIAN
touch $PARENTDIR/autosetup_$VERSION\_$ARCH/DEBIAN/control
echo $VERSION > $PARENTDIR/autosetup_$VERSION\_$ARCH/opt/autosetup/version
echo "Package: autosetup" > $PARENTDIR/autosetup_$VERSION\_$ARCH/DEBIAN/control
echo "Version: $VERSION" >> $PARENTDIR/autosetup_$VERSION\_$ARCH/DEBIAN/control
echo "Architecture: $ARCH" >> $PARENTDIR/autosetup_$VERSION\_$ARCH/DEBIAN/control
echo "Maintainer: Bliksund Danmark" >> $PARENTDIR/autosetup_$VERSION\_$ARCH/DEBIAN/control
echo "Description: Automatic product installation upon reboot." >> $PARENTDIR/autosetup_$VERSION\_$ARCH/DEBIAN/control
cp -R $PARENTDIR/$RANDOMDIR/disabled $PARENTDIR/autosetup_$VERSION\_$ARCH/opt/autosetup/
cp -R $PARENTDIR/$RANDOMDIR/enabled $PARENTDIR/autosetup_$VERSION\_$ARCH/opt/autosetup/
cp $PARENTDIR/$RANDOMDIR/start.sh $PARENTDIR/autosetup_$VERSION\_$ARCH/opt/autosetup/
cp $PARENTDIR/$RANDOMDIR/autoSetup.service $PARENTDIR/autosetup_$VERSION\_$ARCH/etc/systemd/system/
cd $PARENTDIR && dpkg-deb --build autosetup_$VERSION\_$ARCH
rm -rf $PARENTDIR/$RANDOMDIR $PARENTDIR/autosetup_$VERSION\_$ARCH
mv /tmp/autosetup_$VERSION\_$ARCH.deb $CURRENTPATH/release/
echo "Done."
