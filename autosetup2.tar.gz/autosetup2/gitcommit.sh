#!/usr/bin/bash

MESSAGE=$1

if [ -z "$MESSAGE" ]; then
	echo "Syntax error: Missing message"
	echo ""
	echo "Syntax: $0 <message>"
	echo ""
	exit 1
fi

echo "Committing changes to repository."
git add *
git commit -m "$MESSAGE"
git push
echo "Done."
exit 0
