# autoSetup 2.0.0

[![CI](https://github.com/Centralize/autosetup2/actions/workflows/release.yml/badge.svg)](https://github.com/Centralize/autosetup2/actions/workflows/release.yml)

### Install
In the root directory an install script is present.
Running the script will copy all relevant files to <pre>/usr/local/bin</pre> and copy the systemd service file to <pre>/etc/systemd/system</pre>

It will also enable the script to run as a service at boot.

### Uninstall
In the disabled directory a called 99999-selfdestruc.sh is present. This script removes the service from systemd and also removes the relevant files from <pre>/usr/local/bin</pre>
When the 99999-selfdestruct.sh script in run, it is possible within the first 10 second to break the script and by doing so stop the selfdestruction.

### How to use it
AutoSetup is module based. All available modules are placed in the **disabled** directory. To enable a module change directory to enabled and create a symlink to the script placed in the disabled directory, like below. <pre>ln -s ../disabled/00-update.sh</pre>

All active modules placed in the **disabled** directory must have the extension "**.sh**"

All scripts **must** be run as **root** or using a **sudo** session.
