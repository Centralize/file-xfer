#!/bin/bash

a2enmod php8.1
systemctl restart apache2
