#!/usr/bin/bash

# Remove ufw
apt-get remove -y ufw

# Install requirements
apt-get install -qy perl zip unzip libwww-perl liblwp-protocol-https-perl

# Install Send-mail for notifications
#apt-get install -y sendmail-bin

# Install CSF
cd /usr/src && wget https://download.configserver.com/csf.tgz && tar -xzf csf.tgz && cd /usr/src/csf && sh install.sh

# Show CSF version
csf -v



