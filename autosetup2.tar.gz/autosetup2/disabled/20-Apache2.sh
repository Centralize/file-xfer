#!/bin/bash

apt-get update; apt-get install -y apache2 apache2-bin apache2-data apache2-utils libapr1 libaprutil1 libjansson4 ssl-cert openssl
a2enmod headers
a2enmod rewrite
