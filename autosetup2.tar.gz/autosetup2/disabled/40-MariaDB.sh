#!/bin/bash

echo "Installing MariaDB"
apt-get update; apt-get install -y mariadb-server mariadb-client;
exit 0
