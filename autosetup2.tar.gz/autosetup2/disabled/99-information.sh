#!/bin/bash

sudo apt-get -qq update;
sudo apt-get install -qqy net-tools
sudo netstat -lnput

echo "<?php phpinfo();" > /var/www/html/info.php

echo "Done."
