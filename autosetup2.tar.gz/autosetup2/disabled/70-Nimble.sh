#!/bin/bash

echo "Installing Nimble Streaming Server..."
echo -e "deb http://nimblestreamer.com/ubuntu focal/" >> /etc/apt/sources.list
wget -q -O - http://nimblestreamer.com/gpg.key | sudo apt-key add -
apt-get -qq update;
apt-get -qqy install nimble;
systemctl restart nimble;
echo "Done."
exit 0
