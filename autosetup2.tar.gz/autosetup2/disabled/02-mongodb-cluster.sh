#!/bin/bash

echo "Installing wget and curl."
sudo apt-get install -y wget curl openssl libssl1.1 > /dev/null 2>&1

echo "Importing PGP Key."
sudo wget -qO - https://www.mongodb.org/static/pgp/server-5.0.asc | sudo apt-key add -

echo "Writing Repository information."
sudo echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu focal/mongodb-org/5.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-5.0.list

echo "Update Cache"
sudo apt-get update > /dev/null 2>&1

echo "Install MongoDB"
sudo apt-get install -y mongodb-org

echo "Enable on boot and start MongoDB"
sudo systemctl enable mongod; systemctl start mongod

echo "Generating keyfile."
sudo openssl rand -base64 756 > /var/mongoKeyfile
sudo chown mongodb:mongodb /var/mongoKeyfile
sudo chmod 400 /var/mongoKeyfile

echo "Modify /etc/hosts"
IPADDR=`ifconfig | grep -Eo 'inet (addr:)?([0-9]*\.){3}[0-9]*' | grep -Eo '([0-9]*\.){3}[0-9]*' | grep -v '127.0.0.1'`
HN=`hostname`
echo "$IPADDR $HN" >> /etc/hosts
sed -i "s/bindIp: 127.0.0.1/bindIp: 127.0.0.1, $IPADDR/g" /etc/mongod.conf
sed -i "s/#replication:/replication:\n\treplSetName: '$MONGODB_REPLSET_NAME'/g" /etc/mongod.conf
sed -i "s/#security:/security:\n\tkeyFile: \/var\/$MONGODB_SEC_KEYFILE/g" /etc/mongod.conf
systemctl restart mongod

echo "Done."
