#!/bin/bash

PHPDIR="/etc/php"

if [ -d "$DIR" ]; then
  echo "Installing Laravel requirements."
  apt install -qy php8.1-bcmath php8.1-ctype php8.1-fileinfo php8.1-json php8.1-mbstring php8.1-pdo php8.1-tokenizer php8.1-xml
  echo "Enable PHP Mods"
  phpenmod bcmath
  phpenmod ctype
  phpenmod fileinfo
  phpenmod json
  phpenmod mbstring
  phpenmod pdo
  phpenmod tokenizer
  phpenmod xml
else
  echo "PHP isn't installed. Please install PHP 8.1 first."
fi
