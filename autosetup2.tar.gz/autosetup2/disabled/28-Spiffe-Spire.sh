#!/bin/bash

# In summary, these lines of code download the Spire software from a specified URL, extract the software to a specified directory,
# and remove the temporary files that are created during the installation process.

# set -xe # Uncomment for debug mode.

# The first line of code defines a variable called `GITHUB_REPO` and assigns it the value of the URL to a specific release of the Spire software. 
# The second line of code uses the `wget` command to download the Spire software from the URL specified in the `GITHUB_REPO` variable.
GITHUB_REPO="https://github.com/spiffe/spire/releases/download/v1.8.2/spire-1.8.2-linux-amd64-musl.tar.gz"
wget $GITHUB_REPO

# The first line of code extracts the filename from the GITHUB_REPO variable and assigns it to a variable called SOURCE.
# The second line of code extracts the version number from the SOURCE variable and assigns it to a variable called VERSION.
# The third line of code defines a variable called TARGET and assigns it the value of the path to the directory where the Spire software will be installed.
# The fourth line of code creates the TARGET directory if it does not already exist. 
# The fifth line of code extracts the contents of the SOURCE archive to the TARGET directory. 
# The sixth line of code moves all of the files from the spire-$VERSION directory to the TARGET directory. 
# The seventh line of code removes the spire-$VERSION* directory.
SOURCE=$(echo $GITHUB_REPO|cut -d '/' -f9)
VERSION=$(echo $SOURCE|cut -d '-' -f2)
TARGET="/opt/spire"
mkdir -p $TARGET
tar zxf $SOURCE
mv spire-$VERSION/* $TARGET
rm -rf spire-$VERSION*

exit 0