#!/bin/bash

# Check for the distribution
distribution=$(cat /etc/os-release | grep DISTRIB_ID | sed 's/"//g')

# Install Docker Engine
if [[ $distribution == "Ubuntu" ]]; then
  sudo apt update
  sudo apt install docker.io
elif [[ $distribution == "Debian" ]]; then
  sudo apt update
  sudo apt install docker-ce
fi

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/download/v2.5.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Verify the installation
docker version
docker-compose --version
