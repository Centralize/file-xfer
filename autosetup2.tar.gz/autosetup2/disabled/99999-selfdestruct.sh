#!/bin/bash

echo "This scripts will selfdestruct in 10 seconds."
echo "You may use CTRL+C to stop this."
sleep 10s
echo "Bye. ~*Poof*~"
systemctl disable autoSetup.service
rm -rf /etc/systemd/system/autoSetup.service
rm -rf /usr/local/bin/disabled/ /usr/local/bin/enabled/ /usr/local/bin/README.md /usr/local/bin/.git/ /usr/local/bin/start.sh /usr/local/bin/install.sh /usr/local/bin/autoSetup.service
rm -rf /usr/local/bin/autoSetup/
