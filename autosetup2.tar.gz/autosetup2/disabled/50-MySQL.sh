#!/bin/bash

echo "Installing MySQL"
apt-get update; apt-get -qqy install mysql-server mysql-client;
echo "Done."
echo "Remember to run 'mysql -u root << set_mysql_root_passwd.sql'."
exit 0
