#!/bin/bash

# Define the Docker Compose file
cat << EOF > docker-compose.yml
version: '3.9'
services:
  openxpki:
    image: dime/openxpki:latest
    container_name: openxpki
    ports:
      - "8443:8443"
    networks:
      - openxpki
networks:
  openxpki:
    name: openxpki
EOF

# Build and start the container
docker-compose build
docker-compose up -d

# Verify that the container is running
docker-compose ps

rm docker-compose.yml
