#!/bin/bash

echo "Adding Repository for PHP 8.1..."
apt-get update; apt-get upgrade -qy;
apt-get install -qy net-tools vim mc htop
apt-get install lsb-release ca-certificates apt-transport-https software-properties-common -qy

add-apt-repository -y ppa:ondrej/php
apt-get update;

echo "Installing PHP 8.1"
apt-get install -qy apache2 php8.1 php8.1-cli
apt-get install -qy php8.1 php8.1-common php8.1-cli php8.1-imagick php8.1-imap php8.1-mysql php8.1-curl php8.1-gd
apt-get install -qy php-pear php-dev
pecl install mongodb -y
echo "extension=mongodb.so" > /etc/php/8.1/mods-available/incendium-mongodb.ini
phpenmod incendium-mongodb

echo "Done."
exit 0
