#!/bin/bash

VERSION=`lsb_release -a | grep -i "release:" | cut -d ':' -f2 | xargs`

if [ $VERSION == "20.04" ]; then
	echo apt-get update; apt-get install -qqy coturn
fi

