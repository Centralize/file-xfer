#!/bin/bash

# Define the Docker Compose file
cat << EOF > docker-compose.yml
version: '3.9'
services:
  ejbca-ce:
    image: keyfactor/ejbca-ce:latest
    container_name: ejbca-ce
    ports:
      - "80:80"
      - "443:8443"
    networks:
      - ejbca-ce
networks:
  ejbca-ce:
    name: ejbca-ce
EOF

# Build and start the container
docker-compose build
docker-compose up -d

# Verify that the container is running
docker-compose ps

rm docker-compose.yml
