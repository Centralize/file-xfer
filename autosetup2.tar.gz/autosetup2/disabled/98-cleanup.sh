#!/bin/bash

apt-get autoremove -qqy;
