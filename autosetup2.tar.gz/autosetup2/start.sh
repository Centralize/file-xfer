#!/bin/bash

if [ "$EUID" -ne 0 ]; then
  echo "Please run as root"
  exit 1
fi

# VARIABLES
export MONGODB_REPLSET_NAME="autoSetupCluster01"
export MONGODB_SEC_KEYFILE="mongoKeyfile"
export AMS_FILE="ant-media-server-community-2.4.3.zip"

# Run any shell file in mods dir
find /usr/local/bin/enabled/ -name "*.sh" -exec {} \;
