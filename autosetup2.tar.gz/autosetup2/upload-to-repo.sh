#!/usr/bin/bash

HOSTNAME=$1
PORT=$2
USER=$3
VERSION=$4
CURRENTPATH=`pwd`

if [ -z $HOSTNAME ]; then
	echo "Syntax error. Missing Parametres."
	echo ""
	echo "Syntax: $0 <hostname> <port> <username> <version>"
	echo ""
	exit 1
fi

scp -P $PORT $CURRENTPATH/release/autosetup_$VERSION\_amd64.deb $USER@$HOSTNAME:/tmp
