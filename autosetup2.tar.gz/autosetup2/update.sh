#!/bin/bash

git pull
