#!/bin/bash

# DEBUGGING
#set -x

# VARIABLES
slapdPath="/etc/ldap/"
todo=$1
username=$2
fullname=$3
environment=$4
userfile="/etc/ldap/config/ldap-users.ldif"
team=$5
passwd=$(pwgen -cnsB 16 1)
new_uid=$(ldapsearch -x -b 'ou=People,dc=sandbox,dc=lan' -LLL uidNumber=* uidNumber |grep -i "uidNumber" | cut -d ':' -f2 | cut -d ' ' -f2 | sort -n | tail -n 1|awk '{ print $1+1 }')
#new_uid=$(cat $userfile|grep uidNumber|cut -d ' ' -f2|tail -n 1|awk '{ print $1+1 }')
execute_bit=$6

# COLOR CODING
txtblk='\e[0;30m' # Black - Regular
txtred='\e[0;31m' # Red
txtgrn='\e[0;32m' # Green
txtylw='\e[0;33m' # Yellow
txtblu='\e[0;34m' # Blue
txtpur='\e[0;35m' # Purple
txtcyn='\e[0;36m' # Cyan
txtwht='\e[0;37m' # White

# FUNCTIONS
function checkLDAP()
{
  if ! command -v ldapadd &> /dev/null
  then
    echo -e "${txtred}LDAP not found!${txtylw} This must run on a LDAP server.${txtwht}"
    exit 1
  fi
}

function banner()
{
  echo -e "Hamlet LDAP User Tool 0.2"
  echo -e "----------------------------------"
}

function syntax()
{
  echo -e "Syntax: $0 ${txtcyn}<todo> <username> <fullname> <environment> <group> (-x) ${txtwht}"
  echo ""
}

# LOGICS
checkLDAP
if [ -z ${todo} ]; then
  banner
  echo -e "${txtred}Syntax error:${txtwht} ${txtylw}todo is missing.${txtwht}"
  echo ""
  echo -e "${txtwht}Todo:${txtwht} ${txtylw}create${txtwht} or ${txtylw}remove${txtwht}"
  syntax
  exit 1
fi
if [ -z ${username} ]; then
  banner
  echo -e "${txtred}Syntax error: Username must be set.${txtwht} ${txtwht}"
  echo ""
  syntax
  exit 1
fi
if [ -z "$fullname" ]; then
  banner
  echo -e "${txtred}Syntax error: Full name is missing.${txtwht}"
  echo ""
  syntax
  exit 1
fi
if [ -z $environment ]; then
  banner
  echo -e "${txtred}Syntax error: Environment must be set.${txtwht}"
  echo ""
  syntax
  exit 1
fi
if [ -z $team ]; then
  banner
  echo -e "${txtred}Syntax error: Group name must be set. Example: OT-IAM/PKI${txtwht}"
  echo ""
  syntax
  exit 1
fi

touch temp_userfile.ldif
cat << EOF > temp_userfile.ldif
dn: uid=$username,ou=People,dc=$environment,dc=lan
uid: $username
cn: $username
sn: $username
mail: $username@$environment.lan
objectClass: person
objectClass: organizationalPerson
objectClass: inetOrgPerson
objectClass: posixAccount
objectClass: top
objectClass: shadowAccount
userPassword: $passwd
displayName: $fullname
loginShell: /bin/bash
homeDirectory: /home/$username
uidNumber: $new_uid
gidNumber: $new_uid

dn: cn=$team,ou=Groups,dc=$environment,db=lan
changeType: modify
add: memberuid
memberuid: uid=$username,ou=People,dc=$environment,dc=lan
EOF

if [ -z ${execute_bit} ]; then
  cat temp_userfile.ldif
else
  sudo ldapadd -D "cn=admin,dc=$environment,dc=lan" -W -H ldapi:/// -f temp_userfile.ldif
fi

echo -e "${txtred}-------------------------------------${txtwht}"
echo -e "${txtylw}Username:${txtwht} $username"
echo -e "${txtylw}Password:${txtwht} $passwd"
echo -e "${txtylw}New UID:${txtwht} $new_uid | ${txtylw}New GID:${txtwht} $new_uid"
echo -e "${txtred}-------------------------------------${txtwht}"

exit 0
