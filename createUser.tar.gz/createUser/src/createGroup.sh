#!/bin/bash

groupname=$1
groupEnvironment=$2
gidNumber=$(cat /etc/group | cut -d ':' -f 3 | sort -n | tail -n 2 | head -1|awk '{ print $1+1 }')

# COLOR CODING
txtblk='\e[0;30m' # Black - Regular
txtred='\e[0;31m' # Red
txtgrn='\e[0;32m' # Green
txtylw='\e[0;33m' # Yellow
txtblu='\e[0;34m' # Blue
txtpur='\e[0;35m' # Purple
txtcyn='\e[0;36m' # Cyan
txtwht='\e[0;37m' # White

cat << EOF > temp_group.ldif
# create Group for $groupname Team
dn: cn=$groupname,ou=Groups,dc=$groupEnvironment,dc=lan
objectClass: posixGroup
objectClass: top
cn: $groupname
gidNumber: $gidNumber
EOF

echo -e "${txtylw}LDAP Group creation 0.1${txtwht}"
echo -e "-----------------------------------------"
cat temp_group.ldif
echo ""
echo -e "${txtred}-------------------------------------${txtwht}"
echo -e "${txtylw}New Group:${txtwht} $groupname"
echo -e "${txtylw}Next Gid:${txtwht} $gidNumber"
echo -e "${txtylw}Environment:${txtwht} $groupEnvironment.lan"
echo -e "${txtred}-------------------------------------${txtwht}"
