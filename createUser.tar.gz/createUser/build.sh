#!/bin/bash

if ! command -v shc &> /dev/null
then
  echo "Shellscript Compiler not found."
  echo "Install using: apt install -y shc"
  exit 1
else
	shc -f src/createUser.sh -o bin/createUser
	shc -f src/createGroup.sh -o bin/createGroup
	rm -rf src/*.c
fi
exit 0
